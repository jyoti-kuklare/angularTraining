import { Component, OnInit } from '@angular/core';
import { ProductInfo } from '../../../models/app.productinfo.model';
import { HttpService } from '../../../sharedmodule/service/app.http.service';
import { FormGroup, FormControl, Validators} from '@angular/forms' 



@Component({
    selector: 'app-sharedservice-component',
    templateUrl: './app.sharedservice.component.html' 
})
export class SharedServiceComponent implements OnInit {
    products: Array<ProductInfo>;
    tableColumns : Array<string>;
    product : ProductInfo;
    frmProduct: FormGroup;
    flagGetAll = false;
    flagform = false;
    

    // this.flagform=true;
    // this.flagGetAll=false;

    isSaveData:boolean = false;
    constructor(private serv: HttpService) { 
        this.products = new Array<ProductInfo>();
        this.tableColumns = new Array<string>();
        this.product = new ProductInfo();
        

         this.frmProduct = new FormGroup({
            ProductRowId : new FormControl(this.product.ProductRowId),
            ProductId : new FormControl(this.product.ProductId),
            ProductName : new FormControl(this.product.ProductName),
            CategoryName : new FormControl(this.product.CategoryName),
            Description : new FormControl(this.product.Description),
            Manufacturer : new FormControl(this.product.Manufacturer),
            BasePrice : new FormControl(this.product.BasePrice)
        });    
    }

    initProp(){
        this.product.ProductRowId=0;
        this.product.ProductId = '';
        this.product.ProductName = '';
        this.product.CategoryName = '';
        this.product.Description = '';
        this.product.Manufacturer = '';
        this.product.BasePrice = 0;
    }

    ngOnInit(): void { 
        console.log('printing column name');
        for(let p in this.product){
            this.tableColumns.push(p);
        }
        // this.loadData();
    }

    loadData(): void {
        this.flagform=false; 
        this.flagGetAll=true;
        this.serv.getProducts().subscribe((resp) => { 
            this.products = resp;
            // console.log(JSON.stringify(resp));
        });
    }

    clear(){ 
        this.flagform=true;
        this.flagGetAll=false;
        this.product = new ProductInfo();
        this.initProp();
        this.frmProduct.setValue(this.product);
    }

    saveData(){ 
        this.product = this.frmProduct.value;
            if(this.isSaveData){
                this.serv.postProduct(this.product).subscribe((data) =>{ 
                    console.log(data); 
                })
            }
            else{
               this.serv.putProduct(this.product.ProductRowId,this.product).subscribe(data =>{
                this.GatDataFromHHtp()
                console.log(data)
               })
            }
       
        this.product= new ProductInfo();
    }
    GatDataFromHHtp() {
        this.serv.getProducts().subscribe((data) =>{
            this.products = data;
                //console.log(data);
        })
    }

    getSelectedProduct(prod: ProductInfo): void{
        this.flagform= true;
        this.frmProduct.setValue(prod);
    }

    deleteData(id : number){ 
       this.serv.deleteProduct(id).subscribe((data) =>{
        const item = this.products.find(item => item.ProductRowId === id);
        this.products.splice(this.products.indexOf(item));
       })
    }
}