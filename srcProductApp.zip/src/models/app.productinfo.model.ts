export class ProductInfo{
    public ProductRowId : number;
    public ProductId : string;
    public ProductName : string;
    public CategoryName : string;
    public Manufacturer : string;
    public Description : string;
    public BasePrice : number;

    //constructor(){}
    // constructor(ProductRowId : number, ProductId : string, ProductName : string, CategoryName : string, 
    //             Manufacturer : string, Description : string, BasePrice : number) {
    //     this.ProductRowId = ProductRowId;
    //     this.ProductId = ProductId;
    //     this.ProductName = ProductName;
    //     this.CategoryName = CategoryName;
    //     this.Manufacturer = Manufacturer;
    //     this.Description = Description;
    //     this.BasePrice = BasePrice;
    // }
}